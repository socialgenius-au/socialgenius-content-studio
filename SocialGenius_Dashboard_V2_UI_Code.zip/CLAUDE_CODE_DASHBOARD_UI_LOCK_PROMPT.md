# CLAUDE CODE — SOCIALGENIUS DASHBOARD V2 UI INTEGRATION

## GOAL

Integrate the supplied Dashboard V2 UI as two separate parallel screens:

1. `/dashboard-v2`
   - Social Genius company synopsis / management dashboard

2. `/clients/:clientId/dashboard-v2`
   - Client-level dashboard for the selected client

Do NOT replace the existing production Dashboard or Client Overview yet.

## VISUAL SOURCE OF TRUTH

Use:
`frontend/public/dashboard-v2/dashboard-approved-reference.png`

The visual is approved in principle.

The two halves of the reference image are TWO SEPARATE SCREENS, not one live page.

Left = Social Genius Dashboard.
Right = Client Dashboard.

Do not render both side by side in the application.

## NON-NEGOTIABLE DESIGN PRINCIPLE

Dashboard = Synopsis
View More = Detail
Full Tool = Action
Back to Dashboard = Synopsis

Every major dashboard table/card/widget must have a clear `View More`, `View All`, or equivalent action.

Cards should be clickable where appropriate.

Each action should route to the full existing tool rather than trying to place all details on the dashboard.

## COMPANY DASHBOARD

Keep the infographic-rich visual style.

Top KPI cards:
- Due Today
- Overdue
- Awaiting Approval
- Scheduled
- Client Alerts
- Intelligence Opportunities

Overdue is important and must remain prominent.

Main sections:
- Today's Priorities
- Client Health Overview
- Content Pipeline
- Approvals
- Intelligence Alerts
- Overall Performance
- Top Performing Content
- Team Activity
- Quick Create
- AI Management Insight

Use existing Content Studio data/services where compatible, but THIS PASS IS UI ONLY.
Mock data is acceptable for V2 visual verification.

## CLIENT DASHBOARD

This is a completely separate route/view for one client.

Top KPI cards:
- Positioning Score
- Content Due
- Overdue
- Approvals
- Leads
- Performance Score

Sections:
- Positioning & Strategy
- Content Performance
- Top Performing Content
- Content Pipeline
- Intelligence & Opportunities
- Upcoming Work & Overdue
- Campaign Performance
- Lead / Enquiry Performance
- AI Recommendation
- Quick Actions

Every widget must route to the selected client's detailed tool:
- Positioning → `/clients/:clientId/positioning`
- Intelligence → `/clients/:clientId/intelligence`
- Tasks/Overdue → `/clients/:clientId/tasks`
- Analytics → `/clients/:clientId/analytics`
- Leads → `/clients/:clientId/leads`
- Campaigns → `/clients/:clientId/campaigns`
- Library/content → `/clients/:clientId/library`
- Calendar/pipeline → `/clients/:clientId/calendar`
- Strategy recommendation → `/clients/:clientId/strategy`

## CLIENT HEALTH

Do not invent a final health formula yet.

For this visual pass, mock/sample score is acceptable.

Later the score must be defined from agreed factors such as positioning, delivery, approvals, social performance, leads, engagement and unresolved issues.

## THEMING

Use the current Content Studio theme system.

Light and Dark must both work.

Do not create a separate independent theme engine if the AppShell already provides one.

## EXISTING APP

Inspect first:
- `DashboardPage.tsx`
- `ClientOverviewPage.tsx`
- existing AppShell
- common cards/metric components
- client context
- services

Reuse compatible existing pieces without allowing the old layout to dictate the V2 visual.

## THIS PASS

UI integration only.

Do not wire business scoring, AI calculations or live analytics yet.

1. Add the parallel routes.
2. Render both screens separately.
3. Run `tsc --noEmit`.
4. Run `npm run build`.
5. Open `/dashboard-v2`.
6. Open one `/clients/<real-client-id>/dashboard-v2`.
7. Show screenshots in both Light and Dark if practical.
8. Report visual differences from the approved reference.
9. Do not commit.
10. Stop for visual approval.

## DO NOT

- merge company and client dashboards
- remove Overdue
- remove View More actions
- make dashboard widgets dead/static when a route exists
- change existing production routes yet
- redesign the approved hierarchy
