
import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { DashboardShell, Card, CardHeader, Donut } from "./DashboardShell";
import { clientKpis, clientTopContent } from "../data/dashboardMock";

export default function ClientDashboard() {
  const navigate = useNavigate();
  const { clientId = "abc-tiles" } = useParams();
  const go = (path:string) => navigate(path.replace(":clientId",clientId));

  return <DashboardShell clientMode title="Client Dashboard – ABC Tiles" subtitle="One client — complete picture">
    <div className="client-tabs">{["Overview","Positioning","Intelligence","Content","Performance","Leads","Campaigns","Tasks"].map((x,i)=><button className={i===0?"active":""} key={x}>{x}</button>)}</div>

    <div className="kpi-grid client">
      {clientKpis.map(([a,b,c,d],i)=><button className="client-kpi" key={a} onClick={()=>i===0?go("/clients/:clientId/positioning"):i===1||i===2?go("/clients/:clientId/tasks"):i===3?go("/clients/:clientId/publish"):i===4?go("/clients/:clientId/leads"):go("/clients/:clientId/analytics")}>
        <span>{a}</span><b>{b}</b><em>{c}</em><small>{d} →</small>
      </button>)}
    </div>

    <div className="grid-3 client-main">
      <Card>
        <CardHeader title="Positioning & Strategy" action="View positioning →" onClick={()=>go("/clients/:clientId/positioning")}/>
        <p><b>Positioning Statement</b></p>
        <p>Premium quality tiles that transform spaces with style, durability and trust.</p>
        <p><b>Target Segment</b></p><p>Homeowners & Builders</p>
        <p><b>Primary Objective</b></p><p>Increase quality inquiries by 30%</p>
        <div className="progress"><i style={{width:"68%"}}/></div><small>68% strategy progress</small>
      </Card>
      <Card>
        <CardHeader title="Content Performance (This Week)" action="View analytics →" onClick={()=>go("/clients/:clientId/analytics")}/>
        <div className="stats-row"><Stat label="Reach" value="48K" delta="+16%"/><Stat label="Engagement" value="6.2K" delta="+12%"/><Stat label="Inquiries/Leads" value="28" delta="+15%"/><Stat label="Saves" value="820" delta="+10%"/></div>
        <div className="chart client-chart"><svg viewBox="0 0 420 150"><polyline points="0,125 70,94 140,78 210,104 280,85 350,96 420,54" fill="none" stroke="currentColor" strokeWidth="3"/><polyline points="0,140 70,121 140,107 210,124 280,112 350,117 420,93" fill="none" stroke="#7b61ff" strokeWidth="3"/></svg></div>
      </Card>
      <Card>
        <CardHeader title="Top Performing Content" action="View all →" onClick={()=>go("/clients/:clientId/library")}/>
        <div className="content-list">{clientTopContent.map(([a,b,c,d])=><div className="content-row" key={a}><div className="thumb"/><div><b>{a}</b><small>{b}</small></div><strong>{c}</strong><em>{d}</em></div>)}</div>
      </Card>
    </div>

    <div className="grid-3">
      <Card>
        <CardHeader title="Content Pipeline" action="Open pipeline →" onClick={()=>go("/clients/:clientId/calendar")}/>
        <div className="pipeline vertical">{([["Draft",4],["In Review",2],["Approved",3],["Scheduled",6],["Published",22]] as const).map(([a,b])=><div key={a}><span>{a}</span><b>{b}</b><i style={{width:`${Math.min(100,b*4)}%`}}/></div>)}</div>
      </Card>
      <Card>
        <CardHeader title="Intelligence & Opportunities" action="View intelligence →" onClick={()=>go("/clients/:clientId/intelligence")}/>
        <div className="alert-list">
          <div><span className="alert-dot medium">!</span><span>Search demand for “large format tiles” rising in Sydney</span></div>
          <div><span className="alert-dot high">!</span><span>Competitor running discount campaign</span></div>
          <div><span className="alert-dot info">!</span><span>New content opportunity: Bathroom Makeover</span></div>
          <div><span className="alert-dot medium">!</span><span>Audience interest shift: 25–34 age group</span></div>
        </div>
      </Card>
      <Card>
        <CardHeader title="Upcoming Work & Overdue" action="Open tasks →" onClick={()=>go("/clients/:clientId/tasks")}/>
        <div className="work-list">
          <div><span className="red">Overdue</span><b>3</b></div>
          <div><span>Due Today</span><b>6</b></div>
          <div><span>Due This Week</span><b>9</b></div>
          <div><span>Due Next Week</span><b>12</b></div>
        </div>
      </Card>
    </div>

    <div className="grid-3">
      <Card>
        <CardHeader title="Campaign Performance" action="View campaigns →" onClick={()=>go("/clients/:clientId/campaigns")}/>
        <h4>Winter Collection Promotion</h4>
        <div className="stats-row"><Stat label="Reach" value="32K" delta="+18%"/><Stat label="Engagement" value="4.8K" delta="+12%"/><Stat label="Leads" value="18" delta="+20%"/></div>
        <div className="progress"><i style={{width:"72%"}}/></div><small>Campaign 72% complete</small>
      </Card>
      <Card>
        <CardHeader title="Lead / Enquiry Performance" action="View leads →" onClick={()=>go("/clients/:clientId/leads")}/>
        <div className="lead-panel"><Donut value={28} label="Leads"/><ul><li>New 12 (43%)</li><li>Contacted 8 (29%)</li><li>Qualified 5 (18%)</li><li>Proposal Sent 3 (10%)</li></ul></div>
        <p><b>Conversion Rate: 17.8%</b></p>
      </Card>
      <Card className="ai-card">
        <CardHeader title="AI Recommendation" action="View recommendations →" onClick={()=>go("/clients/:clientId/strategy")}/>
        <ul><li>Focus on “Before/After Transformation” content.</li><li>Promote large format tiles with real projects.</li><li>Run engagement campaign for 25–34 audience.</li><li>Create reel series on tile installation tips.</li></ul>
        <button>Generate Strategy Note</button>
      </Card>
    </div>

    <Card className="quick-card">
      <CardHeader title="Quick Actions" action=""/>
      <div className="quick-actions">{["Create Post","Create Reel","Create Carousel","View Calendar","View Tasks","Add New Task","Upload Media"].map(x=><button key={x}>{x}</button>)}</div>
    </Card>
  </DashboardShell>
}
function Stat({label,value,delta}:{label:string;value:string;delta:string}) {
  return <div className="stat"><span>{label}</span><b>{value}</b><em>{delta}</em></div>
}
