
import React from "react";
import { useNavigate } from "react-router-dom";
import { DashboardShell, Card, CardHeader, MiniTrend } from "./DashboardShell";
import { companyKpis, clientHealth, priorities, approvals, alerts, topContent, teamActivity } from "../data/dashboardMock";

export default function CompanyDashboard() {
  const navigate = useNavigate();
  return <DashboardShell title="Good Morning, Ayub 👋" subtitle="Here's what's happening across Social Genius today.">
    <div className="kpi-grid company">
      {companyKpis.map((k,i)=><button className={`kpi-card tone-${k.tone}`} key={k.label} onClick={()=>navigate(k.route)}>
        <span className="kpi-label">{k.label}</span>
        <div className="kpi-value">{k.value}</div>
        <small>{k.delta}</small>
        <MiniTrend tone={k.tone}/>
        <b>{k.action} →</b>
      </button>)}
    </div>

    <div className="grid-2 mainrow">
      <Card>
        <CardHeader title="Today's Priorities" action="View all tasks →" onClick={()=>navigate("/tasks")}/>
        <div className="priority-list">
          {priorities.map(([task,time,priority])=><div className="priority-row" key={task}>
            <span className="dot"/><b>{task}</b><small>{time}</small><em className={`priority ${priority.toLowerCase()}`}>{priority}</em>
          </div>)}
        </div>
      </Card>
      <Card className="dark-card">
        <CardHeader title="Client Health Overview" action="View all clients →" onClick={()=>navigate("/clients")}/>
        <table className="health-table"><thead><tr><th>Client</th><th>Health Score</th><th>Trend</th><th>At Risk Areas</th></tr></thead><tbody>
          {clientHealth.map(([name,score,trend,risk])=><tr key={name}><td>{name}</td><td><b>{score}</b><span className="health-bar"><i style={{width:score}}/></span></td><td className={trend}>{trend==="up"?"↗":trend==="down"?"↘":"→"}</td><td>{risk}</td></tr>)}
        </tbody></table>
      </Card>
    </div>

    <div className="grid-3">
      <Card>
        <CardHeader title="Content Pipeline" action="View full pipeline →" onClick={()=>navigate("/calendar")}/>
        <div className="pipeline">
          {([["Draft",24,"blue"],["In Review",12,"orange"],["Approved",18,"green"],["Scheduled",22,"violet"],["Published",56,"teal"]] as const).map(([a,b,c])=><div className={`pipe ${c}`} key={a}><span>{a}</span><b>{b}</b></div>)}
        </div>
        <div className="pipe-line"/>
      </Card>
      <Card>
        <CardHeader title="Approvals" action="Open workspace →" onClick={()=>navigate("/approvals")}/>
        <div className="simple-list">{approvals.map(([a,b])=><div key={a}><span>{a}</span><b>{b}</b></div>)}</div>
      </Card>
      <Card>
        <CardHeader title="Intelligence Alerts" action="View intelligence →" onClick={()=>navigate("/intelligence")}/>
        <div className="alert-list">{alerts.map(([a,t])=><div key={a}><span className={`alert-dot ${t}`}>!</span><span>{a}</span></div>)}</div>
      </Card>
    </div>

    <div className="grid-3 performance-row">
      <Card className="span-2">
        <CardHeader title="Overall Performance (This Week)" action="View analytics →" onClick={()=>navigate("/analytics")}/>
        <div className="stats-row"><Stat label="Reach" value="248K" delta="+18%"/><Stat label="Engagement" value="32.6K" delta="+11%"/><Stat label="Leads" value="1.2K" delta="+8%"/><Stat label="Shares" value="3.7K" delta="+22%"/></div>
        <div className="chart"><svg viewBox="0 0 640 160"><polyline points="0,130 80,95 160,118 240,75 320,105 400,88 500,92 640,55" fill="none" stroke="currentColor" strokeWidth="3"/><polyline points="0,145 80,120 160,135 240,110 320,127 400,118 500,122 640,98" fill="none" stroke="#7b61ff" strokeWidth="3"/></svg></div>
      </Card>
      <Card>
        <CardHeader title="Top Performing Content" action="View library →" onClick={()=>navigate("/library")}/>
        <div className="content-list">{topContent.map(([a,b,c,d])=><div className="content-row" key={a}><div className="thumb"/><div><b>{a}</b><small>{b}</small></div><strong>{c}</strong><em>{d}</em></div>)}</div>
      </Card>
    </div>

    <div className="grid-2 last-row">
      <Card>
        <CardHeader title="Team Activity" action="View team →" onClick={()=>navigate("/tasks")}/>
        <div className="team-grid">{teamActivity.map(([a,b,c])=><div key={a}><div className="tiny-avatar">{a[0]}</div><div><b>{a}</b><span>{b}</span></div><small>{c}</small></div>)}</div>
      </Card>
      <Card className="ai-card">
        <CardHeader title="AI Management Insight" action="Open recommendations →" onClick={()=>navigate("/intelligence")}/>
        <p><b>7 overdue deliverables.</b> 3 clients need attention this week. ABC Tiles has a new positioning opportunity and 2 intelligence alerts worth reviewing.</p>
        <button>Get Management Suggestions →</button>
      </Card>
    </div>

    <Card className="quick-card">
      <CardHeader title="Quick Create" action=""/>
      <div className="quick-actions">{["Create Post","Create Reel","Create Carousel","AI Prompt","Blog / Article","Press Release"].map(x=><button key={x}>{x}</button>)}</div>
    </Card>
  </DashboardShell>
}

function Stat({label,value,delta}:{label:string;value:string;delta:string}) {
  return <div className="stat"><span>{label}</span><b>{value}</b><em>{delta}</em></div>
}
