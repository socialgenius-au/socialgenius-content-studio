
import React from "react";

export function DashboardShell({ children, title, subtitle, clientMode = false }:{
  children: React.ReactNode;
  title: string;
  subtitle?: string;
  clientMode?: boolean;
}) {
  return (
    <div className="dashv2-page">
      <header className="dashv2-pagehead">
        <div>
          <h1>{title}</h1>
          {subtitle && <p>{subtitle}</p>}
        </div>
        <div className="dashv2-head-actions">
          {clientMode && <select className="dashv2-client-select"><option>ABC Tiles</option></select>}
          <div className="dashv2-search">⌕ Search content, tasks, insights...</div>
          <button className="dashv2-create">+ Create</button>
          <button className="dashv2-iconbtn">🔔<span>12</span></button>
          <div className="dashv2-user"><div className="avatar">AS</div><div><b>Ayub Shariff</b><small>Director</small></div></div>
        </div>
      </header>
      {children}
    </div>
  );
}

export function Card({ children, className = "" }:{children:React.ReactNode;className?:string}) {
  return <section className={`dash-card ${className}`}>{children}</section>
}

export function CardHeader({ title, action = "View more →", onClick }:{title:string;action?:string;onClick?:()=>void}) {
  return <div className="dash-card-head"><h3>{title}</h3><button onClick={onClick}>{action}</button></div>
}

export function MiniTrend({ tone="green" }:{tone?:string}) {
  return <svg className={`mini-trend ${tone}`} viewBox="0 0 90 24" aria-hidden="true">
    <polyline fill="none" stroke="currentColor" strokeWidth="2" points="2,19 16,17 27,10 39,16 52,12 63,15 76,7 88,9"/>
  </svg>
}

export function Donut({ value, label }:{value:number;label:string}) {
  return <div className="donut" style={{["--value" as string]:`${value * 3.6}deg`}}>
    <div><b>{value}%</b><span>{label}</span></div>
  </div>
}
