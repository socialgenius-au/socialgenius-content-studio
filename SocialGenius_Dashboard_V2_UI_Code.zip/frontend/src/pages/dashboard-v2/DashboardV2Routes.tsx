
import React from "react";
import CompanyDashboard from "./components/CompanyDashboard";
import ClientDashboard from "./components/ClientDashboard";

export function CompanyDashboardV2() {
  return <CompanyDashboard />;
}

export function ClientDashboardV2() {
  return <ClientDashboard />;
}
