
export const companyKpis = [
  { label: "Due Today", value: 12, delta: "+3 vs yesterday", tone: "blue", action: "View Tasks", route: "/tasks" },
  { label: "Overdue", value: 7, delta: "+2 vs yesterday", tone: "red", action: "View Overdue", route: "/tasks?filter=overdue" },
  { label: "Awaiting Approval", value: 5, delta: "+1 vs yesterday", tone: "violet", action: "View Approvals", route: "/approvals" },
  { label: "Scheduled", value: 18, delta: "+6 vs last week", tone: "teal", action: "View Schedule", route: "/calendar" },
  { label: "Client Alerts", value: 3, delta: "2 high priority", tone: "orange", action: "View Alerts", route: "/clients?filter=alerts" },
  { label: "Intelligence Opportunities", value: 7, delta: "+2 new", tone: "green", action: "View Intelligence", route: "/intelligence" },
] as const;

export const clientHealth = [
  ["ABC Tiles", "85%", "up", "Content, Engagement"],
  ["Smplee Packaging", "78%", "up", "Reach"],
  ["Luxury Cars", "74%", "flat", "Leads"],
  ["Hamari Dukaan", "52%", "down", "Engagement, Content"],
  ["Budget Mart", "70%", "up", "Reach"],
] as const;

export const priorities = [
  ["ABC Tiles — Create 3 reels", "9:00 AM", "High"],
  ["Smplee Packaging — Q3 Promo", "10:30 AM", "High"],
  ["Luxury Cars — Reel + Carousel", "11:00 AM", "Medium"],
  ["Hamari Dukaan — Strategy Review", "1:00 PM", "Medium"],
  ["QC pending — 2 posts", "3:30 PM", "Low"],
] as const;

export const approvals = [
  ["Content awaiting internal review", 5],
  ["Content awaiting client approval", 3],
  ["QC issues to resolve", 1],
] as const;

export const alerts = [
  ["Competitor 'XYZ Tiles' launched new campaign", "high"],
  ["Search demand rising for porcelain tiles", "medium"],
  ["New trend: Before/After Transformation", "medium"],
  ["Audience shift detected: 25–34 age group", "info"],
] as const;

export const topContent = [
  ["3 Pricing Mistakes to Avoid", "ABC Tiles · Reel", "82K", "+24%"],
  ["Behind the Scenes at Smplee", "Smplee Packaging · Post", "41K", "+18%"],
  ["Why Choose Quality Cars?", "Luxury Cars · Reel", "35K", "+15%"],
] as const;

export const teamActivity = [
  ["Sameena", "Video Studio V2", "2m ago"],
  ["Iqra", "Creating — ABC Tiles Post", "15m ago"],
  ["Khudsia", "Reference Library", "25m ago"],
  ["Zeeshan", "QC Review", "40m ago"],
] as const;

export const clientKpis = [
  ["Positioning Score", "78%", "Strong", "View Positioning"],
  ["Content Due", "6", "Today", "View Tasks"],
  ["Overdue", "3", "High Priority", "View Overdue"],
  ["Approvals", "2", "Waiting", "View Approvals"],
  ["Leads (This Week)", "28", "+15%", "View Leads"],
  ["Performance Score", "82%", "Good", "View Analytics"],
] as const;

export const clientTopContent = [
  ["Modern Tile Trends 2026", "Reel · Aug 18", "12.4K", "+24%"],
  ["Before/After – Living Room", "Carousel · Aug 17", "8.7K", "+18%"],
  ["How to Choose Right Tile", "Post · Aug 19", "6.1K", "+15%"],
] as const;
