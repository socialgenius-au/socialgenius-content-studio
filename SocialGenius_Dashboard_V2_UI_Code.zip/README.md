# SocialGenius Dashboard V2 UI

Contains two separate dashboards:

- Company Dashboard: `/dashboard-v2`
- Client Dashboard: `/clients/:clientId/dashboard-v2`

The approved reference is included at:
`frontend/public/dashboard-v2/dashboard-approved-reference.png`

Source:
`frontend/src/pages/dashboard-v2/`

Use `CLAUDE_CODE_DASHBOARD_UI_LOCK_PROMPT.md` when integrating with Claude Code.

This package is for UI integration first. Existing live Dashboard and Client Overview should remain untouched until V2 is visually approved.
